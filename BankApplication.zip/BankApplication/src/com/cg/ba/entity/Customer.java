package com.cg.ba.entity;

public class Customer {
private String customerId;
private String CustomerName;
private String password;
private int customerAge;
private String customerNumber;
private String emailId;
private long depositAmount;
public String getCustomerName() {
	return CustomerName;
}

public void setCustomerName(String customerName) {
	CustomerName = customerName;
}
public int getCustomerAge() {
	return customerAge;
}
public void setCustomerAge(int customerAge) {
	this.customerAge = customerAge;
}
public String getCustomerNumber() {
	return customerNumber;
}
public void setCustomerNumber(String phone) {
	this.customerNumber = phone;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public long getDepositAmount() {
	return depositAmount;
}
public void setDepositAmount(long depositAmount) {
	this.depositAmount = depositAmount;
}
public String getCustomerId() {
	return customerId;
}
public void setCustomerId(String customerId) {
	this.customerId = customerId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", CustomerName=" + CustomerName + ", password=" + password
			+ ", customerAge=" + customerAge + ", customerNumber=" + customerNumber + ", emailId=" + emailId
			+ ", depositAmount=" + depositAmount + "]";
}
}
