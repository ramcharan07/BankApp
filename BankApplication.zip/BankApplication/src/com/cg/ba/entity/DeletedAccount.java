package com.cg.ba.entity;

public class DeletedAccount {
private String deletedId;

public String getDeletedId() {
	return deletedId;
}

public void setDeletedId(String deletedId) {
	this.deletedId = deletedId;
}

@Override
public String toString() {
	return "DeletedAccount [deletedId=" + deletedId + "]";
}


}
