package com.cg.ba.ui;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import com.cg.ba.entity.Admin;
import com.cg.ba.entity.Customer;
import com.cg.ba.entity.DeletedAccount;
import com.cg.ba.service.AdminServiceImpl;
import com.cg.ba.service.IAdminServices;
import com.cg.ba.service.IUserServices;
import com.cg.ba.service.UserImpl;
import com.cg.ba.validation.Validations;


public class MainBank {
      
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		Validations valid=new Validations();
		System.out.println("welcome to  Bank Application");
		System.out.println("1.Register to open Account");
		System.out.println("2.Login ");
		System.out.println("3.Exit");
		
		while(true) {
		System.out.println("Select ur choice");
		int choice = 0;
		try {
			choice = sc.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("enter only digits");
			System.exit(0);
		}
		
		switch (choice) {
		case 1:
			sc.nextLine();
			System.out.println("Enter name:");
			String name = sc.nextLine();
			
			System.out.println("Enter Age:");
			int age = 0;
			try {
				age = sc.nextInt();
			} catch (InputMismatchException e) {
				System.err.println("age should contain only digits");
				System.exit(0);
			}
			System.out.println("Enter MobileNumber:");
			String phone = null;
			try {
				phone = sc.next();
			} catch (InputMismatchException e) {
				System.err.println("phone number should contain only digits");
				System.exit(0);
			}
			sc.nextLine();
			System.out.println("Enter email id");
			String emailid = sc.next();
			System.out.println("Enter password");
			String password = sc.next();
           
			System.out.println("Enter the deposit amount");
			long deposit=0;
			try {
				deposit=sc.nextLong();
			}catch(InputMismatchException e) {
				System.err.println("Amount should be in number");
			System.exit(0);
			}
			
			
			Customer customer=new Customer();
			customer.setCustomerNumber(phone);
			customer.setCustomerName(name);
			customer.setEmailId(emailid);
			customer.setCustomerAge(age);
            customer.setDepositAmount(deposit);
			customer.setPassword(password);
            try {
			boolean result = valid.validateUsers(customer);
   
				if (result) {
					String accountId=new AdminServiceImpl().addDetails(customer);;
					//customer.setCustomerId(accountId);
					System.out.println("Your Account id is : " + accountId);
				}

			} catch (Exception e) {
				System.err.println(e.getMessage());
			}
			break;
		case 2:
			System.out.println("1.ADMIN Login ");
			System.out.println("2.USER Login");
			System.out.println("3.exit");
			while(true) {
			System.out.println("Select ur choice");
			int login = 0;	
			try {
				login = sc.nextInt();
			} catch (InputMismatchException e) {
				System.out.println("enter only digits");
				System.exit(0);
			}
		switch(login) {
		case 1:
			Admin admin=new Admin();
			System.out.println("Enter the admin id");
		       int adminId=sc.nextInt();
		       System.out.println("enter the admin password");
		       String adminPassword=sc.next();
		       System.out.println("enter admin name");
		       String adminUserName=sc.next();
		       admin.setUserId(adminId);
		       admin.setUserName(adminUserName);
		       admin.setPassword(adminPassword);
		      if( valid.isValidAdimUser(admin)) {
             adminOption();       
		      }
		      else
		    	  System.out.println("Enter the valid admin details");
		       break;
		case 2:
			System.out.println("Enter the account id");
			String userId=sc.next();
			System.out.println("enter the user password");
			String userPassword=sc.next();
		    
		    try {
		    	IAdminServices ad=new AdminServiceImpl();
			    Customer cutom=new Customer();
				cutom=ad.viewUserById(userId);
				//System.out.println(cutom.getCustomerId());
				if(valid.isValidateUser(cutom, userId, userPassword)) {
				userOption(userId);
				}
				else {
					System.out.println("check your password");
				}
			} catch (SQLException e) {
				
			 System.out.println("enter the valid ID");
			}
		
			break;
		       
		case 3:
			 System.exit(0);
		}
			}
		case 3:
			System.exit(0);
		}
	}
}

public static void adminOption() {
	Scanner scan=new Scanner(System.in);
	System.out.println("Select an option");
	System.out.println("1.View Details");
	System.out.println("2.view users by range");
	System.out.println("3.view deleted Account Numbers");
	int operate = 0;	
	try {
		operate = scan.nextInt();
	} catch (InputMismatchException e) {
		System.out.println("enter only digits");
		System.exit(0);
	}
	switch(operate) {
	case 1:
		IAdminServices admin=new AdminServiceImpl();
		List<Customer> list=new ArrayList<Customer>();
		try {
			list=admin.viewAllUsers();
			System.out.println(list);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		break;
	
	case 2:IAdminServices admin1=new AdminServiceImpl();

	System.out.println("enter the lowest amount");
	long amount1=scan.nextLong();
	System.out.println("enter the highest amount");
	long amount2=scan.nextLong();
	List<Customer> list1=new ArrayList<Customer>();
		try {
			list1=admin1.userByRange(amount1, amount2);
			if(list1!=null)
			System.out.println(list1);
			else
				System.out.println("there are no accounts having balace in that range");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		break;
	case 3:IAdminServices admin2=new AdminServiceImpl();

           List<DeletedAccount> list3=new ArrayList<>();
		try {
			list3=admin2.viewDeletedId();
			if(list3!=null)
			System.out.println(list3);
			else
				System.out.println("there are no deleted accounts ");
		} catch (SQLException e) {
			e.printStackTrace();
		}
			
		break;

	}
}
public static void userOption(String userId)  {
	Scanner scan=new Scanner(System.in);
	System.out.println("Select an option");
	System.out.println("1.Withdraw");
	System.out.println("2.Deposit");
	System.out.println("3.Check Balance");
	System.out.println("4.delete Account");
	System.out.println("5.View My Details");
	int operate = 0;	
	try {
		operate = scan.nextInt();
	} catch (InputMismatchException e) {
		System.out.println("enter only digits");
		System.exit(0);
	}
	switch(operate) {
	case 1:
		System.out.println("Enetr the amount You want to withdraw");
		try {
		long withdraw=scan.nextLong();
		IUserServices d1=new UserImpl();
		try {
			d1.withDraw(withdraw, userId);
		} catch (SQLException e) {
		       }
		}
		catch(Exception e) {
			System.out.println("Enter only digits");
		}
		
		break;
	case 2:
		System.out.println("enetr the amount you want to deposit");
		long deposit=scan.nextLong();
		IUserServices d2=new UserImpl();
		try {
			d2.deposit(deposit, userId);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		break;
		
	case 3:
	              IUserServices d3=new UserImpl();
	              long balance=0;
		try {
			balance =d3.checkBalance(userId);
			System.out.println("Your current Balance is "+balance);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		
		break;
	case 4:
		System.out.println("are you sure do u like to delete");
		IUserServices d=new UserImpl();
		try {
			d.deleteAccount(userId);
			System.out.println("deleted sucessfully");
		} catch (SQLException e) {
	System.out.println("problem in deleting!!!");
		}
		break;
	case 5:
		IAdminServices admin1=new AdminServiceImpl();
		Customer customer=new Customer();
		try {
			customer=admin1.viewUserById(userId);
			System.out.println(customer);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		break;
	
}
}
}