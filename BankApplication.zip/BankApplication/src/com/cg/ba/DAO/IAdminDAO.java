package com.cg.ba.DAO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.ba.entity.Customer;

public interface IAdminDAO {
	public String addDetails(Customer customer) throws SQLException, NumberFormatException, IOException;	
	
	public List viewAllUsers() throws SQLException;
	
	public Customer viewUserById(String id) throws SQLException;
	
	public String getId() throws NumberFormatException, IOException;
	
	public List viewDeletedId() throws SQLException;
	
	public List userByRange(Long amount1,long amount2) throws SQLException;
}
