package com.cg.ba.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.ba.exception.BankException;
import com.cg.ba.utility.Utility;

public class UserDAOImpl implements IUserDAO{

	@Override
	public long withDraw(long withdraw,String userId) throws SQLException {
		long money=0;
		Connection con=Utility.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		ps=con.prepareStatement("select depositAmount from customer where customerId=?");
		
		ps.setString(1, userId);
		rs=ps.executeQuery();
		rs.next();
		money=rs.getLong(1);
		ps.close();
		if(money>=withdraw) {
			money=money-withdraw;
			ps=con.prepareStatement("update customer set depositAmount=? where customerId=?");
			ps.setLong(1, money);
			ps.setString(2, userId);
			ps.executeUpdate();
		
		}
		else {
			try {
				throw new BankException("u dont have enough balance");
			} catch (BankException e) {
			
			}
		}
		return money;
	}

	@Override
	public long deposit(long deposit,String customerId) throws SQLException {
		long money =0;
		Connection con=Utility.getConnection();
		Statement st=null;
		PreparedStatement ps=null;
		ResultSet rs= null;
          st=con.createStatement();
          rs=st.executeQuery("select depostiAmount from customer where customerId=?");
          rs.next();
        money=rs.getLong(1);
        try {
        if(deposit>0) {
        	money +=deposit;
        }
        else
             throw new BankException("deposit can't be 0");
        }
        catch(BankException e) {
        	
        }
        return money;
        
	}

	@Override
	public void deleteAccount(String userId) throws SQLException {
		int update=0;
		Connection con=Utility.getConnection();
		PreparedStatement st=con.prepareStatement("insert into deletedCustomer values(?)");
		st.setString(1, userId);
		update=st.executeUpdate();
		if(update!=0) {
		PreparedStatement ps=con.prepareStatement("delete from customer where customerId=?");
		ps.setString(1, userId);
        int i=ps.executeUpdate();

		}
		
		st.close();
		con.close();
	}
		
	

	@Override
	public long checkBalance(String customerId) throws SQLException {
		Connection con=Utility.getConnection();
		Statement st=null;
		ResultSet rs=null;
		st=con.createStatement();
		rs=st.executeQuery("select depositAmount from customer where customerId=?");
	        rs.next();
		return rs.getLong(1);
		
	}

}
