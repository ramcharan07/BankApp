package com.cg.ba.DAO;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.ba.entity.Customer;
import com.cg.ba.entity.DeletedAccount;
import com.cg.ba.utility.Utility;


public class AdminDAOImpl implements IAdminDAO {
Connection con=null;
	@Override
	public String addDetails(Customer customer) throws SQLException, NumberFormatException, IOException 
	{
		con=Utility.getConnection();
		Statement st=con.createStatement();
		ResultSet rs=null;
		String id=null;
		rs=st.executeQuery("select deletedId from deletedCustomer order by deletedID ");
		if(rs.next()) {
		           id=rs.getString(1);
		       	PreparedStatement st1=con.prepareStatement("delete from deletedCustomer where deletedId=?");
				st1.setString(1, id);
				st1.executeUpdate();
		}
		else {
			id=getId();
		     }
		PreparedStatement ps=con.prepareStatement("insert into customer values(?,?,?,?,?,?,?)");
		ps.setString(1, id);
		ps.setString(2,customer.getCustomerName());
		ps.setString(3,customer.getPassword());
		ps.setInt(4,customer.getCustomerAge());
		ps.setString(5, customer.getCustomerNumber());
		ps.setString(6,customer.getEmailId());
		ps.setLong(7, customer.getDepositAmount());
		int i=ps.executeUpdate();
		if(i!=0)
			System.out.println("sucessfully added");
		else
			System.out.println("something went wrong!!!");
		
		
		ps.close();
		con.close();
		
		return id;
	}


	@Override
	public List<Customer> viewAllUsers() throws SQLException {
		con=Utility.getConnection();
		Statement st=con.createStatement();
		ArrayList<Customer> al=new ArrayList<>();
		ResultSet rs=st.executeQuery("select * from customer");
		while(rs.next()) {
			Customer customer=new Customer();
			customer.setCustomerId(rs.getString(1));
			customer.setCustomerName(rs.getString(2));
			customer.setPassword(rs.getString(3));
			customer.setCustomerAge(rs.getInt(4));
			customer.setCustomerNumber(rs.getString(5));
			customer.setEmailId(rs.getString(6));
			customer.setDepositAmount(rs.getLong(7));
			al.add(customer);
		}
		return al;
	}

	@Override
	public Customer viewUserById(String userId) throws SQLException {
		Customer customer=new Customer();
		con=Utility.getConnection();
		PreparedStatement ps=con.prepareStatement("select * from customer where customerId=?");
		ps.setString(1, userId);
		ResultSet rs=ps.executeQuery();
		if(rs.next()) {
			
			customer.setCustomerId(rs.getString(1));
			customer.setCustomerName(rs.getString(2));
			customer.setPassword(rs.getString(3));
			customer.setCustomerAge(rs.getInt(4));
			customer.setCustomerNumber(rs.getString(5));
			customer.setEmailId(rs.getString(6));
			customer.setDepositAmount(rs.getLong(7));
			
		}
		ps.close();
		con.close();
		if(customer!=null) {
			return customer;
		}
		else
			return null;
	
		
	}

	@Override
	public   String getId() throws NumberFormatException, IOException {
		FileReader fr = new FileReader("count_user.txt");
		BufferedReader br = new BufferedReader(fr);
		int rd = Integer.parseInt(br.readLine());
		int inc = rd + 1;
		FileOutputStream fw = new FileOutputStream("count_user.txt");
		fw.write(Integer.toString(inc).getBytes());
		fw.close();
		String date = "" + java.time.LocalDate.now();
		String yy = date.substring(2, 4);
		String mm = date.substring(5, 7);
		FileReader fr1 = new FileReader("count_user.txt");
		BufferedReader br1 = new BufferedReader(fr1);
		int b = Integer.parseInt(br1.readLine());

		String s1 = null;

		if (b < 10)
			s1 = "000" + b;
		if (b > 10 && b < 100)
			s1 = "00" + b;
		if (b >= 100)
			s1 = "0" + b;
		String id = yy + mm + s1;
		br1.close();
		fr1.close();
		br.close();
		fr.close();
        return id;
        
	}

	@Override
	public List<DeletedAccount> viewDeletedId() throws SQLException {
		List<DeletedAccount> list=new ArrayList<>();
		con=Utility.getConnection();
		ResultSet rs=null;
		Statement st=con.createStatement();
		rs=st.executeQuery("select * from deletedCustomer");
		while(rs.next()) {
			DeletedAccount delete=new DeletedAccount();
			delete.setDeletedId(rs.getString(1));
			list.add(delete);
		}
		
		st.close();
		con.close();
		return list;
	}


	@Override
	public List<Customer> userByRange(Long amount1, long amount2) throws SQLException {
		con=Utility.getConnection();
		List<Customer> list=new ArrayList<>();
		PreparedStatement st=con.prepareStatement("select * from customer where depostiAmount BETWEEN ? AND ?");
		st.setLong(1, amount1);
		st.setLong(2, amount2);
		ResultSet rs=st.executeQuery();
		while(rs.next()) {
			Customer customer=new Customer();
			customer.setCustomerId(rs.getString(1));
			customer.setCustomerName(rs.getString(2));
			customer.setPassword(rs.getString(3));
			customer.setCustomerAge(rs.getInt(4));
			customer.setCustomerNumber(rs.getString(5));
			customer.setEmailId(rs.getString(6));
			customer.setDepositAmount(rs.getLong(7));
			list.add(customer);
		}
		return list;
	}
  

}
