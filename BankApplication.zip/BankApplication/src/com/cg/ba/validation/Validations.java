package com.cg.ba.validation;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ba.entity.Admin;
import com.cg.ba.entity.Customer;



public class Validations {
	public boolean validateUsers(Customer customer) throws Exception
	{    
		boolean result=true;
		List<String> validationErrors = new ArrayList<String>();

		if(!(isValidName(customer.getCustomerName()))) {
			validationErrors.add("\n customer Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		
		if(!(isValidPhoneNumber(customer.getCustomerNumber()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		
		if(!(isValidAmount(customer.getDepositAmount()))){
			validationErrors.add("\n Amount Should be a positive Number \n" );
		}
		
		if(!validationErrors.isEmpty()) {
			result=false;
			throw new Exception(validationErrors +"");
		}
		else
		result=true;
		return result;

	}
	
	public boolean isValidName(String customerNmae){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(customerNmae);
		return nameMatcher.matches();
	}

	
	public boolean isValidPhoneNumber(String phoneNumber){
		String phoneregEx = "[6-9][0-9]{9}";
		Pattern pattern = Pattern.compile(phoneregEx);
		Matcher matcher = pattern.matcher(phoneNumber);
		return matcher.matches();
		
	}
	public boolean isValidAmount(double amount){
		return (amount>0);
	}
   public boolean isValidAdimUser(Admin admin) {
	   if(admin.getUserId()==5307 && admin.getPassword().equals(new String("RamCharan"))&& admin.getUserName().equals(new String("hell_in_the_well"))) {
		   return true;
	   }
	return false;

   }
   public boolean isValidateUser(Customer customer,String userId,String userPaswword) {
	   if(customer.getCustomerId().equals(userId) && customer.getPassword().equals(userPaswword)) {
		   return true;
	   }
	   else
	   return false;
   }
   
}