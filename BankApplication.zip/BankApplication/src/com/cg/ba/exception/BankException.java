package com.cg.ba.exception;

public class BankException extends Exception{

	public BankException(String message) {
		System.out.println(message);
	}

}
