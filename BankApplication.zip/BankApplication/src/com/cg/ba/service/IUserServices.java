package com.cg.ba.service;

import java.sql.SQLException;

public interface IUserServices {

	public long withDraw(long withdraw,String userId) throws SQLException;
	
	public long deposit(long deposit,String customerId) throws SQLException;
	
	public void deleteAccount(String userId) throws SQLException;
	
	public long checkBalance(String customerId) throws SQLException;

}
