package com.cg.ba.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ba.DAO.AdminDAOImpl;
import com.cg.ba.DAO.IAdminDAO;
import com.cg.ba.entity.Customer;
import com.cg.ba.entity.DeletedAccount;

public class AdminServiceImpl implements IAdminServices{
public static IAdminDAO adminDAO=null;
	@Override
	public String addDetails(Customer customer) throws SQLException, NumberFormatException, IOException {
		adminDAO=new AdminDAOImpl();
		return adminDAO.addDetails(customer);
	
	}

	@Override
	public List viewAllUsers() throws SQLException {
		adminDAO=new AdminDAOImpl();
	List<Customer> list=new ArrayList<>();
		list=adminDAO.viewAllUsers();
		return list;
	}

	@Override
	public Customer viewUserById(String id) throws SQLException {
	   Customer customer=new Customer();
		   adminDAO=new AdminDAOImpl();
	 customer= adminDAO.viewUserById(id);
		return customer;
	}

	@Override
	public String getId() throws NumberFormatException, IOException {
		adminDAO=new AdminDAOImpl();
		String yourId=adminDAO.getId();
		return yourId;
	}

	@Override
	public List viewDeletedId() throws SQLException {
		adminDAO=new AdminDAOImpl();
		List<DeletedAccount> list=new ArrayList<>();
		list=adminDAO.viewDeletedId();
		return list;
	}

	@Override
	public List userByRange(Long amount1, long amount2) throws SQLException {
		adminDAO=new AdminDAOImpl();
		List<Customer> list=new ArrayList<>();
		adminDAO.userByRange(amount1, amount2);
		return list;
	}



}
