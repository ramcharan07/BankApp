package com.cg.ba.service;

import java.sql.SQLException;

import com.cg.ba.DAO.IAdminDAO;
import com.cg.ba.DAO.IUserDAO;
import com.cg.ba.DAO.UserDAOImpl;

public class UserImpl implements IUserServices {
        public  static IAdminDAO adminDAo=null;
        public static IUserDAO userDAO=null;
	@Override
	public long withDraw(long withdraw, String userId) throws SQLException {
		userDAO=new UserDAOImpl();
		return userDAO.withDraw(withdraw, userId);
	}

	@Override
	public long deposit(long deposit, String customerId) throws SQLException {
		userDAO=new UserDAOImpl();
		return userDAO.deposit(deposit, customerId);
		
	}

	@Override
	public void deleteAccount(String userId) throws SQLException {
		userDAO=new UserDAOImpl();
		userDAO.deleteAccount(userId);
		
	}

	@Override
	public long checkBalance(String customerId) throws SQLException {
		userDAO=new UserDAOImpl();
		return userDAO.checkBalance(customerId);
	}


}
